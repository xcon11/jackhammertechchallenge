﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TechChallenge.Models;

namespace TechChallenge.Controllers
{
    public class GetController : ApiController
    {

        [HttpGet()]
        [ActionName("reverse-words")]
        ////[Route("api/controller/action/{word}")]
        public HttpResponseMessage reverse(string word)
        {
            try
            {
                StringWorker worker = new StringWorker();

                var reversedWord = worker.ReverseWord(word);

                var message = Request.CreateResponse(HttpStatusCode.Created, reversedWord);

                return message;
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Reversing Word Failed");
            }
        }
        [HttpGet()]
        [ActionName("sort-words")]
        //[Route("api/controller/action/{word}")]
        public HttpResponseMessage sort(string word)
        {
            try
            {
                StringWorker worker = new StringWorker();

                var reversedWord = worker.SortSWord(word);

                var message = Request.CreateResponse(HttpStatusCode.Created, reversedWord);

                return message;
            }
            catch (Exception xc)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Sorting Failed");
            }

        }

        [HttpGet()]
        [ActionName("calculate-after-tax-income")]
        public HttpResponseMessage CalculateAfterTax(double salary)
        {
            try
            {
                TaxCalculator calculator = new TaxCalculator(new AfterTaxStrat());

                var afterTaxIncome = calculator.ComputeSalary(salary);

                var message = Request.CreateResponse(HttpStatusCode.Created, afterTaxIncome);

                return message;
            }
            catch (Exception xc)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Computation Failed");
            }

        }

        [HttpGet()]
        [ActionName("calculate-pre-tax-income-from-take-home")]
        public HttpResponseMessage CalculatePreTax(double salary)
        {
            try
            {
                TaxCalculator calculator = new TaxCalculator(new PreTaxStrat());

                var afterTaxIncome = calculator.ComputeSalary(salary);

                var message = Request.CreateResponse(HttpStatusCode.Created, afterTaxIncome);

                return message;
            }
            catch (Exception xc)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Computation Failed");
            }

        }
    }
}
