﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TechChallenge.Models;

namespace TechChallenge.Controllers
{
    [RoutePrefix("api/reverse-words")]
    public class ReverseController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage Get(string word)
        {
            try
            {
                StringWorker worker = new StringWorker();

                var reversedWord = worker.ReverseWord(word);

                var message = Request.CreateResponse(HttpStatusCode.Created, reversedWord);

                return message;
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }


       


    }
}
