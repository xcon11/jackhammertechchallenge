﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechChallenge.Models
{
    public interface IStringWorker
    {
         string ReverseWord(string word);

         string SortSWord(string word);
    }
}