﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechChallenge.Models
{
    public class StringWorker : IStringWorker
    {
        public StringWorker()
        {
        }

        public string ReverseWord(string word)
        {
            char[] charArray = word.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }

        public string SortSWord(string word)
        {

            return DoSort(word);
        }

        private string DoSort(string word)
        {
            char[] arr1;
            char ch;
            int i, j, l;
          
            l = word.Length;
            arr1 = word.ToCharArray(0, l);

            for (i = 1; i < l; i++)
                for (j = 0; j < l - i; j++)

                    if (arr1[j] > arr1[j + 1])
                    {
                        ch = arr1[j];
                        arr1[j] = arr1[j + 1];
                        arr1[j + 1] = ch;
                    }
            

            return new string(arr1);
        }
    }
}