﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechChallenge.Models
{
    public class PreTaxStrat : TaxCalculatorStrategy
    {
       

        public override SalaryModel Calculate(double salary)
        {
            double bracketA = 18200;
            double bracketB = 37000;
            double bracketC = 87000;
            double bracketD = 180000;

           
            SalaryModel salaryModel = new SalaryModel();
            salaryModel.BaseSalary = salary;

            return salaryModel;
        }
    }
}