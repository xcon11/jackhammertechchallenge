﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechChallenge.Models
{
    public class TaxCalculator
    {
        private TaxCalculatorStrategy _strategy;

        
        public TaxCalculator(TaxCalculatorStrategy strategy)
        {
            this._strategy = strategy;
        }

        public SalaryModel ComputeSalary(double salary)
        {
            return _strategy.Calculate(salary);
        }
    }
}