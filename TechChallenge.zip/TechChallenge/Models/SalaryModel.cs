﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechChallenge.Models
{
    public class SalaryModel
    {
      public double BaseSalary { get; set; }
        public double PostTaxIncome { get; set; }
        public double Superannuation { get; set; }
        public Taxes Taxes { get; set; }

      
    }

    public class Taxes
    {
        public double income { get; set; }
        public double medicare { get; set; }
        public double total { get; set; }


    }
}