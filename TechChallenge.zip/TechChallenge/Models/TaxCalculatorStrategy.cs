﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechChallenge.Models
{
    public abstract class TaxCalculatorStrategy
    {
       public abstract SalaryModel Calculate(double salary);
    }
}