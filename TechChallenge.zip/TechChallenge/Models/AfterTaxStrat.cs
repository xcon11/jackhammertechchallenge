﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechChallenge.Models
{
    public class AfterTaxStrat : TaxCalculatorStrategy
    {
        public override SalaryModel Calculate(double salary)
        {
            SalaryModel salaryModel = new SalaryModel();
            salaryModel.BaseSalary = salary;

            return salaryModel;
        }
    }
}